package miembrosMesa;

public enum Tipo {
    presidente, 
    secretario, 
    vocal,
}
