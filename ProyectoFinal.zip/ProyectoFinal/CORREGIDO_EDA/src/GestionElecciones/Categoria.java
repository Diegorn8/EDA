package GestionElecciones;

public enum Categoria {
    Presidencial,
    Regional,
    Municipal,
}
